﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Autokauppa.controller;
using Autokauppa.model;

// EDELLINEN, SEURAAVA, TALLENNA -painikkeita TEHTÄVÄSSÄ K3
// POLTTOAINE, VÄRI, comboboxit TEHTÄVÄSSÄ H2


namespace Autokauppa.view
{ 
    public partial class MainMenu : Form
    {
         KaupanLogiikka registerHandler;

        public MainMenu()
        {
            registerHandler = new KaupanLogiikka();
            InitializeComponent();
        }
           
        public void testaaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*   
              // TEHTÄVÄN 12 YHTEYDEN TESTAUS
               //Yhteyden testaus
               string connectionString;
               SqlConnection cnn;
               connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Autokauppa; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
               cnn = new SqlConnection(connectionString);
              // cnn.Open();

               if (cnn.State == ConnectionState.Open)
               {
                   MessageBox.Show("Yhteys toimii!","Yhteys");
               }
               if(cnn.State != ConnectionState.Open)
               {
                   MessageBox.Show("Jokin meni vikaan yhteyden muodostamisessa tietokantaan.","Yhteysvirhe");
               }
               cnn.Close();
            */

            //Yhteyden testaus tietokantaan
            KaupanLogiikka dbTesti = new KaupanLogiikka();
            bool testi = dbTesti.TestDatabaseConnection();

            if (testi == true)
            { MessageBox.Show("Yhteys onnistuu"); }
            if (testi == false)
            { MessageBox.Show("Jokin meni pieleen"); }

        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            //Kutsutaan jotain ja lisätään listalla olevat merkit comboboxiin
            comboBoxMerkit.DataSource = registerHandler.getAllAutoMakers();
            comboBoxMerkit.DisplayMember = "MerkkiNimi";
            comboBoxMerkit.ValueMember = "Id";

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Sulkee ohjelman
            Application.Exit();
        }

        private void comboBoxMerkit_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Tulostetaan valitun automerkin mallit comboboxiin
            int valinta;
            Int32.TryParse(comboBoxMerkit.SelectedValue.ToString(), out valinta);

            comboBoxMallit.DataSource = registerHandler.getAutoModels(valinta);
            comboBoxMallit.DisplayMember = "MalliNimi";
            comboBoxMallit.ValueMember = "Id";
        }
    }
}
